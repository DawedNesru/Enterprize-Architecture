package edu.mum.cs.cs544.examples;

public class CustomerService {
	public CustomerService() {
		System.out.println("CustomerService constructor called");
	}
	
	public void sayHello() {
		System.out.println("Hello from CustomerService");
	}
}