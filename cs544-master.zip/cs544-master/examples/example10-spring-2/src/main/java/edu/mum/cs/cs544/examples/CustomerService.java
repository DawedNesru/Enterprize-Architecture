package edu.mum.cs.cs544.examples;

public interface CustomerService {
	public void addCustomer(String customername);
	public void init();
	public void cleanup();
}
