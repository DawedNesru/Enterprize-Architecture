package edu.mum.cs.cs544.examples.config;

import org.springframework.context.annotation.Configuration;

/**
 * Root context configuration
 * 
 * @author Anil
 *
 */
@Configuration
public class WebConfig {

}
