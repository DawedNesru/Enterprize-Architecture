package cs544.exercise15_1;

public interface BillingService {
    public void printBills();
}
