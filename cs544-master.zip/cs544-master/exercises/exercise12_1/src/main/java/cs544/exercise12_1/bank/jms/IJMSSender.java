package cs544.exercise12_1.bank.jms;

public interface IJMSSender {
	public void sendJMSMessage (String text);
}
