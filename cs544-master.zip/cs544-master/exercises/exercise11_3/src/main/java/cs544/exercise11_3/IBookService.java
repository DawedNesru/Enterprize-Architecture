package cs544.exercise11_3;

public interface IBookService {
    public void buy(Book book);
}
