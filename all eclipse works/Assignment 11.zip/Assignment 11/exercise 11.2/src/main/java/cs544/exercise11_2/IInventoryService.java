package cs544.exercise11_2;

public interface IInventoryService {
	public long getNumberInStock();
}
