package cs544.exercise11_2;

public class InventoryService implements IInventoryService {

	

	public long getNumberInStock() {
	
		return 78;
	}

}
