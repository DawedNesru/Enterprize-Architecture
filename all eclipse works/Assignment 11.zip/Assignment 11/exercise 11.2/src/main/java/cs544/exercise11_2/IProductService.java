package cs544.exercise11_2;

public interface IProductService {
	public Product getProduct(int productNumber);

	public long getNumberInStock();
}
