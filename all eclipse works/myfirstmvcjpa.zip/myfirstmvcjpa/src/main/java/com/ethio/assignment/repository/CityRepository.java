package com.ethio.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ethio.assignment.model.*;

public interface CityRepository extends JpaRepository<City, Integer>{

}
