package com.ethio.assignment.service;

import java.util.List;

import com.ethio.assignment.model.Country;

public interface CountryService {
	
	public List<Country> getAllCountry();

}
