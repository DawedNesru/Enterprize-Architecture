package com.example.demo.service;

import java.util.List;

import com.example.demo.service.response.CityResponse;

public class CityServiceImpl implements CityService{

	@Override
	public List<CityResponse> getAllCities() {
		
		return null;
	}

	@Override
	public List<CityResponse> getAllCitiesByCountryId(Integer countryId) {
		// TODO Auto-generated method stub
		return null;
	}

}
